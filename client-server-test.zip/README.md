README
------
Load into eclipse run as spring boot project. Try the following from
postman:
GET http://localhost:8080/borderInfo?currency=gbp and
you will get the following result:
[
    [
        "ATA",
        "GGY",
        "IMN",
        "JEY",
        "SGS",
        "GBR",
        "ZWE"
    ],
    [
        "IRL",
        "BWA",
        "MOZ",
        "ZAF",
        "ZMB"
    ]
]
